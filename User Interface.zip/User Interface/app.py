from flask import Flask, render_template, request
import random
from transformers import GPT2LMHeadModel, GPT2Tokenizer

app = Flask(__name__, template_folder='templates')

# Load the GPT-2 model and tokenizer
tokenizer = GPT2Tokenizer.from_pretrained("gpt2")
model = GPT2LMHeadModel.from_pretrained("gpt2")

def generate_shuffled_creative_caption_gpt2(text, category):
    prompt = f"Given the text: '{text}' and category: '{category}', generate a unique and creative caption:"
    input_ids = tokenizer.encode(prompt, return_tensors="pt")
    output = model.generate(input_ids, max_length=100, num_return_sequences=1, no_repeat_ngram_size=2)
    
    generated_caption = tokenizer.decode(output[0], skip_special_tokens=True)
    words = generated_caption.split()
    random.shuffle(words)
    
    # Limit the caption to 50 words
    caption_words = words[:50]
    final_caption = ' '.join(caption_words)
    
    return final_caption

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        text = request.form['text']
        category = request.form['category']
        caption = generate_shuffled_creative_caption_gpt2(text, category)
        return render_template('index.html', text=text, category=category, caption=caption)
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)